<!DOCTYPE html>
<html>
<body>


<?php
/*
ITEC 370
Author(s): chris blankenship
*/

// name


$servername = "localhost";
$username = "root";
$password = "th_";
$dbname = "th_";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn -> connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT cname, email FROM clients";
$sql_store = "INSERT INTO clients (cname, email) values (" . $_POST["name"] . "," . $_POST["email"] . "); commit;";

$conn->query($sql_store);


$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["cname"]. " - Name: " . $row["email"]."<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>



<form action="th_.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br><br>
Heart Rate: <br> 
Initial: <input type="text" name="heart initial"><br>
Excerise: <input type="text" name="heart excer"><br>
Recovery: <input type="text" name="heart recov"><br><br>

Blood Pressure:  <input type="text" name="bp"><br>

Weight:  <input type="text" name="weight"> *in pounds <br>
Height:  <input type="text" name="height"> *in inches <br>
BMI:  <input type="text" name="BMI"><br>
Flexibility: <input type="text" name="flex"><br><br>

Lifts: <br>
Squat: <input type="text" name="squat"><br>
Bench: <input type="text" name="bench"><br>
Deadlift: <input type="text" name="dl"><br><br>

Notes: <input type="text" name="notes"><br>
<input type="submit">
</form>


 
</body>
</html>